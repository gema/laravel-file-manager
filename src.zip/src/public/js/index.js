(() => {
    console.log('hello from pckg!')
})()