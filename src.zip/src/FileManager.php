<?php

namespace GemaDigital\FileManager;

class FileManager
{
    // Build wonderful things
}
